const jwt = require('jsonwebtoken');
const CONFIG = require('../config/config');

module.exports = (req, res, next) => {
    if (req.path != "/login") {
        let path = req.path.split('/')[1];
        if(path == 'get-image'){
            return next();
        }
        if (req.headers.authorization) {
            let token = req.headers.authorization.split(' ')[1];
            jwt.verify(token, CONFIG.SECRET_TOKEN, (err, decoded) => {
                if (err) return res.status(500).send({ message: "NO AUTHORIZATION", err });
                const rol = decoded.role;
                if (req.method != 'GET') {
                    if (rol == 'editor') {
                        if (req.method == 'DELETE') return res.status(401).send({ message: "NO AUTHORIZATION", err });
                        if (req.path == '/user') {
                            return res.status(401).send({ message: "NO AUTHORIZATION", err });
                        } else {
                            return next();
                        }
                    }
                    if (rol == 'admin') next();
                    else return res.status(403).send({ message: "NO AUTHORIZATION", err });
                } else {
                    if (rol == 'view') {
                        if (req.path == '/user') {
                            return res.status(403).send({ message: "NO AUTHORIZATION", err });
                        } else {
                            return next();
                        }
                    } else {
                        return next();
                    }
                }
            });
        } else res.status(403).send({ message: 'NO AUTHORIZATION' });
    } else next();
}