const fs = require('fs');
const path = require('path');

const getImage = (req, res) => {
    let file = req.params.image;
    let path_file = './update/avatar/'+file;
    fs.exists(path_file, (exist) => {
        if(exist) return res.sendFile(path.resolve(path_file));
        else return res.status(404).send({message: 'imagen no encontrada'});
    });

};

module.exports = {getImage};