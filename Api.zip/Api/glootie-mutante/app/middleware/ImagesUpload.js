const pather = require('path')
const multer = require('multer');

const storage = multer.diskStorage({
  destination:(req, file, callback) => {
    callback(null, './update/images');
  },
  filename:(req, file, callback) => {
    callback(null, file.fieldname + '-' + Date.now() + pather.extname(file.originalname));
   
  }
});

const ImageUpload = multer({storage});

module.exports = ImageUpload;