const mongoose = require('mongoose');
const CONFIG = require('./config');

module.exports = {
    connection: null,
    connect: () => {
        if(this.connection) return this.connection;
        return mongoose.connect(CONFIG.DB).then(conn => {
            this.connection = conn;
            console.log("Conexión Exitosa");
        }).catch(err => console.log(err));
    }
}