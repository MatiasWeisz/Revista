module.exports = {
    PORT: process.env.PORT || 3000,
    DB: process.env.DB || 'mongodb://localhost:27017/glootie',
    SECRET_TOKEN: process.env.SECRET_TOKEN || 'pepe salta y el salta salta'
}