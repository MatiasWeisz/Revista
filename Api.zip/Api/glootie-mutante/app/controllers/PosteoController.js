const Posteo = require('../model/Posteo');

const index = (req, res) => {
    Posteo.find({}).then(post => {
        if (post.length) return res.status(200).send({ post });
        return res.status(204).send({ message: 'NO CONTENT' });
    }).catch(err => res.status(500).send({ err }));
};

const show = (req, res) => {
    const error = req.body.error;
    if (error) return res.status(500).send({ error });
    if (!req.body.posteo) return res.status(404).send({ message: 'NO CONTENT' });
    let posteo = req.body.posteo;
    return res.status(200).send({ posteo });
};

const create = (req, res) => {
    console.log(req.body);
    const save = true;
    const ImagesName = req.file ? `/update/images/${req.file.filename}` : null;
    if (req.file) {
        if (req.file.mimetype != 'image/png' && req.file.mimetype != 'image/jpg' && req.file.mimetype != 'image/jpeg') {
            save = false;
            fs.unlink(`.${ImagesName}`, (err) => {
                console.log('Error?:' + err);
            });
            return res.status(500).send({ message: 'Type image invalido', type: 'png, jpg, jpeg' });
        }
    }
    if (save) {
        console.log('entre a save');
        req.body.imagePortada = ImagesName;
        new Posteo(req.body).save().then(posteo => res.status(200).send({ posteo })).catch(err => res.status(500).send({message: 'Fields Error'}));
    }
    
};

const update = (req, res) => {
    const save = true;
    const ImagesName = req.file ? `/update/images/${req.file.filename}` : req.body.imagePortada;
    if (req.file) {
        if (req.file.mimetype != 'image/png' && req.file.mimetype != 'image/jpg' && req.file.mimetype != 'image/jpeg') {
            save = false;
            fs.unlink(`.${ImagesName}`, (err) => {
                console.log('Error?:' + err);
            });
            return res.status(500).send({ message: 'Type image invalido', type: 'png, jpg, jpeg' });
        }else{
            req.body.imagePortada = ImagesName;
        }
    }
    if (save) {
        console.log('entre a save');
        let posteo = req.body.posteo[0];
        posteo = Object.assign(posteo, req.body);
        posteo.save().then(posteo => res.status(200).send({message: 'update', posteo })).catch(err => res.status(500).send({message: 'Fields Error'}));
    }
};

const destroy = (req, res) => {
    const error = req.body.error;
    if (error) return res.status(500).send({ error });
    if (!req.body.posteo) return res.status(404).send({ message: 'NOT FOUND' });
    fs.unlink(`.${req.body.posteo[0].imagePortada}`, (err) => {
        console.log('Error?:' + err);
    });
    req.body.posteo[0].remove().then(posteo => res.status(200).send({ message: 'Remove', posteo })).catch(error => res.status(500).send(error));
};

const find = (req, res, next) => {
    let query = {};
    query[req.params.key] = req.params.value;
    Posteo.find(query).then(posteo => {
        if (!posteo.length) return next();
        req.body.posteo = posteo;
        return next();
    }).catch(error => {
        req.body.error = error;
        next();
    });
}

module.exports = { index, show, create, update, destroy, find };