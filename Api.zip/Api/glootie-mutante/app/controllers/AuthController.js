const User = require('../model/User');
const bcryp = require('bcrypt-nodejs');
const CONFIG = require('../config/config');

const jwt = require('jsonwebtoken');

const session = (req, res) => {
    let password = req.body.password;
    let username = req.body.username;
    User.find({ username: username }).then(user => {
        if (!user) return res.status(404).send({ message: 'NO Content' });
        bcryp.compare(password, user[0].password, (err, access) => {
            if (!access) {
                res.status(200).send({ message: "Password o Username Incorrectos" });
            } else {
                payload = {
                    username: user[0].username,
                    email: user[0].email,
                    name: user[0].name,
                    role: user[0].role,
                    avatar: user[0].avatar,
                }
                jwt.sign(payload, CONFIG.SECRET_TOKEN, (err, token) => {
                    if (err) {
                        res.status(500).send({ err });
                    } else {
                        console.log(payload);
                        res.status(200).send({ message: 'Hola Mutante', token, user: payload });
                    }
                });
            }
        });
    }).catch(err => {
        return res.status(500).send({ message: err });
    });
}

module.exports = {session};