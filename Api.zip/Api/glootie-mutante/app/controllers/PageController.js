const Page = require('../model/Pages');

const index = (req, res) => {
    Page.find({}).then(page => {
        if (page.length) return res.status(200).send({ page });
        return res.status(204).send({ message: 'NO CONTENT' });
    }).catch(err => res.status(500).send({ err }));
}

const show = (req, res) => {
    const error = req.body.error;
    if (error) return res.status(500).send({ error });
    if (!req.body.page) return res.status(404).send({ message: 'NO CONTENT' });
    let page = req.body.page;
    return res.status(200).send({ page });
}

const create = (req, res) => {
    const page = req.body;
    console.log(page);
    new Page(page).save().then(page => res.status(200).send({ page })).catch(err => res.status(500).send({message: 'Fields Error'}));
}

const update = (req, res) => {

}

const destroy = (req, res) => {

}

const find = (req, res, next) => {
    let query = {};
    query[req.params.key] = req.params.value;
    Page.find(query).then(page => {
        if (!page.length) return next();
        req.body.page = page;
        return next();
    }).catch(error => {
        req.body.error = error;
        next();
    });
}

module.exports = { index, show, create, update, destroy, find };