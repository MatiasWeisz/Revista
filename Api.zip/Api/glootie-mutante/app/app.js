const express = require('express');
const bodyParser = require('body-parser');
const User = require('./routes/user');
const Auth = require('./routes/auth');
const ViewImages = require('./routes/viewImages');
const Posteo = require('./routes/posteo');
const Page = require('./routes/page');
const cors = require('cors');
const App = express();
const AuthToken = require('./middleware/AuthToken');


//Cors
App.use(cors());
App.options('*', cors());
//middlewares
App.use(AuthToken);
App.use(bodyParser.json());
App.use(bodyParser.urlencoded({ extended: false }));

//Routes
App.use('/user', User);
App.use('/login', Auth);
App.use('/get-image', ViewImages);
App.use('/posteo', Posteo);
App.use('/page', Page);

module.exports = App;