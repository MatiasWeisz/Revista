const express = require('express');
const PageController = require('../controllers/PageController');
const path = '/:key/:value';
const Router = express.Router();


Router.get('/',PageController.index)
      .post('/',PageController.create)
      .get(path,PageController.find,PageController.show)
      .put(path,PageController.find,PageController.update)
      .delete(path,PageController.find,PageController.destroy)

module.exports = Router;