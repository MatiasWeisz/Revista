const express = require('express');
const UserController = require('../controllers/UserController');
const ImageUpload = require('../middleware/ImagesUpload');
const path = '/:key/:value';
const Router = express.Router();


Router.get('/',UserController.index)
      .post('/',ImageUpload.single('avatar'),UserController.create)
      .get(path,UserController.find,UserController.show)
      .put(path,ImageUpload.single('avatar'),UserController.find,UserController.update)
      .delete(path,UserController.find,UserController.destroy)

module.exports = Router;