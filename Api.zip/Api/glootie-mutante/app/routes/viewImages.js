const express = require('express');
const ViewImages = require('../middleware/ViewImages');
const Router = express.Router();

Router.get('/update/avatar/:image', ViewImages.getImage);

module.exports = Router;