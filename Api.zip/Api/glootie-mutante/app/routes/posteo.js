const express = require('express');
const PosteoController = require('../controllers/PosteoController');
const ImageUpload = require('../middleware/ImagesUpload');
const path = '/:key/:value';
const Router = express.Router();


Router.get('/',PosteoController.index)
      .post('/',ImageUpload.single('imagePortada'),PosteoController.create)
      .get(path,PosteoController.find,PosteoController.show)
      .put(path,ImageUpload.single('imagePortada'),PosteoController.find,PosteoController.update)
      .delete(path,PosteoController.find,PosteoController.destroy)

module.exports = Router;