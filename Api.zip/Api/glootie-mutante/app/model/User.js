const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    company: {
        type: String,
        required: false,
        enum: ['mutante']
    },
    name: {
        type: String,
        required: true
    },
    username: {
        type: String,
        required: true,
        unique: true
    },
    role: {
        type: 'String',
        default: 'view',
        enum: ['view','editor','admin']
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true,
    },
    avatar:{
        type: String,
        default: undefined
    },
    sign_up_date: {
        type: Date,
        default: Date.now()
    },
    last_login_date: {
        type: Date,
        default: Date.now()
    }
});

const User = mongoose.model('User', UserSchema);
module.exports = User;