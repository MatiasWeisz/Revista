const mongoose = require('mongoose');


const PosteoSchema = new mongoose.Schema({
    title: {
        type: 'String',
        required: true,
    },
    description: {
        type: 'String',
        required: true,
    },
    imagePortada: {
        type: 'String',
        required: false,
        default: undefined
    },
    usernameCreador: {
        type: 'String',
        required: true,
    },
    view: {
        type: Boolean,
        default: false,
    },
    viewHome: {
        type: Boolean,
        default: false
    },
    etiqueta:{
        type: String,
        required: true
    },
    created_at: { type: Date },
    updated_at: { type: Date }
});

PosteoSchema.pre('save', function (next) {
    now = new Date();
    this.updated_at = now;
    if (!this.created_at) {
        this.created_at = now;
    }
    next();
});

const Posteo = mongoose.model('Posteo', PosteoSchema);
module.exports = Posteo;