const mongoose = require('mongoose');

const PageSchema = new mongoose.Schema({
    data:{
        type: String,
        required: true,
    },
    numPage:{
        type: Number,
        required: false
    },
    id_posteo:{
        type: String,
        required: true
    },
    etiqueta:{
        type: String,
        required: true
    },
    created_at: { type: Date },
    updated_at: { type: Date }
});

PageSchema.pre('save', function (next) {
    now = new Date();
    this.updated_at = now;
    if (!this.created_at) {
        this.created_at = now;
    }
    next();
});

const Page = mongoose.model('Page', PageSchema);
module.exports = Page;