# ApiRest de Mutante

---

## ROLES: 

* View 

Acceso a las peticiones GET menos la de visualizar Usuarios

* Editor

Acceso a Todas las peticiones, menos DELETE

* Admin

Acceso a Todas las peticiones

## POST USER
```
{
    "company": "mutante",
    "name": "Mutante",
    "username": "mutanteWeb",
    "passoword": "1234",
    "email": "mutante@mutanteweb.com",
    "role": "admin"
}
``` 
